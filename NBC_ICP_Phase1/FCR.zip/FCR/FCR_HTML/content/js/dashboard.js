/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.82752436034141, "KoPercent": 0.17247563965858667};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9002049069565174, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9943458345261953, 500, 1500, "CustomerManager_doAdvancedCustomerSearch"], "isController": false}, {"data": [0.9914646574943583, 500, 1500, "CurrencyRateManager_Inquire"], "isController": false}, {"data": [0.8564778077553827, 500, 1500, "demandDepositSatatementManager_InquireListofTransactions"], "isController": false}, {"data": [0.9776291397364597, 500, 1500, "CustomerManager_Inquire"], "isController": false}, {"data": [0.5771670817028342, 500, 1500, "DemandDepositMaintenance_InquireAccountMasterForMaintenance"], "isController": false}, {"data": [0.8476886962802456, 500, 1500, "DemandDepositManager_TransferFunds"], "isController": false}, {"data": [0.35337320784589676, 500, 1500, "DemandDepsoit_addEarmarkFunds"], "isController": false}, {"data": [0.8661007667031764, 500, 1500, "BillPaymentManager_PayUtilityBillByAccount"], "isController": false}, {"data": [0.9953328017261598, 500, 1500, "CurrencyRateManager_ConvertAmount"], "isController": false}, {"data": [0.9934640522875817, 500, 1500, "MemoManager_InquireAccountMemo"], "isController": false}, {"data": [0.9658243682762071, 500, 1500, "LoansManager_InquireLoanAccount"], "isController": false}, {"data": [0.9832380743020444, 500, 1500, "PersonalDataManager_Inquire"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 203507, 351, 0.17247563965858667, 356.55607915206207, 70, 27429, 220.0, 602.0, 1138.9500000000007, 1491.0, 56.51003789235638, 1112.8885341484522, 79.54116712930066], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["CustomerManager_doAdvancedCustomerSearch", 20958, 0, 0.0, 212.63989884530977, 127, 3016, 191.0, 296.0, 351.0, 507.0, 5.8211071935863945, 26.613601262646007, 7.708419291506983], "isController": false}, {"data": ["CurrencyRateManager_Inquire", 27474, 0, 0.0, 202.94751401324933, 118, 6540, 176.0, 274.0, 333.0, 510.0, 7.631238469396995, 82.56033977833049, 13.997269068166174], "isController": false}, {"data": ["demandDepositSatatementManager_InquireListofTransactions", 18903, 0, 0.0, 403.1864783367712, 172, 4693, 298.0, 684.0, 820.0, 1320.8399999999965, 5.250124566516853, 658.2278650411708, 8.510934085964367], "isController": false}, {"data": ["CustomerManager_Inquire", 19959, 0, 0.0, 303.39360689413365, 150, 27429, 257.0, 430.0, 487.0, 743.4000000000015, 5.543362879049204, 54.21146008481548, 10.079290184780845], "isController": false}, {"data": ["DemandDepositMaintenance_InquireAccountMasterForMaintenance", 16866, 0, 0.0, 632.850171943553, 242, 4226, 594.0, 824.3000000000011, 945.0, 1395.0, 4.684016356565121, 150.38079280911774, 5.969376313786605], "isController": false}, {"data": ["DemandDepositManager_TransferFunds", 5538, 175, 3.1599855543517514, 453.5855904658718, 240, 3693, 431.0, 578.0, 648.0, 860.4399999999987, 1.538199168183664, 6.493650731748676, 2.4535094152551693], "isController": false}, {"data": ["DemandDepsoit_addEarmarkFunds", 11369, 176, 1.5480693112850734, 1351.8129123053957, 155, 4202, 1334.0, 1604.0, 1662.5, 1852.2999999999993, 3.1570163710001014, 6.214087884439428, 5.19079000861869], "isController": false}, {"data": ["BillPaymentManager_PayUtilityBillByAccount", 1826, 0, 0.0, 459.2557502738225, 280, 3538, 434.0, 595.0, 654.0, 874.3800000000001, 0.5073462401920469, 1.0905847840062293, 1.1449972276209184], "isController": false}, {"data": ["CurrencyRateManager_ConvertAmount", 21319, 0, 0.0, 191.64867020029027, 114, 2850, 171.0, 268.0, 319.0, 488.0, 5.921194426483757, 14.142710814355876, 7.644367271204675], "isController": false}, {"data": ["MemoManager_InquireAccountMemo", 21114, 0, 0.0, 204.50734110069078, 70, 3792, 181.0, 285.0, 336.0, 548.0, 5.8647702964967205, 14.106685986396089, 10.778806345709793], "isController": false}, {"data": ["LoansManager_InquireLoanAccount", 19985, 0, 0.0, 300.2660995746793, 156, 3412, 248.0, 460.0, 531.0, 765.1399999999994, 5.550873891144544, 73.25202762438153, 6.082126957266326], "isController": false}, {"data": ["PersonalDataManager_Inquire", 18196, 0, 0.0, 277.80775994724144, 160, 3667, 241.0, 391.0, 453.1499999999978, 715.0599999999977, 5.053801488588396, 25.83211993880362, 0.0], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["500\/Internal Server Error", 351, 100.0, 0.17247563965858667], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 203507, 351, "500\/Internal Server Error", 351, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["DemandDepositManager_TransferFunds", 5538, 175, "500\/Internal Server Error", 175, null, null, null, null, null, null, null, null], "isController": false}, {"data": ["DemandDepsoit_addEarmarkFunds", 11369, 176, "500\/Internal Server Error", 176, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
