/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.97563709009404, "KoPercent": 0.024362909905959167};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9640594162252, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.515625, 500, 1500, "Enter_Response_Code-0"], "isController": false}, {"data": [0.9927152317880795, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC05_Click_Confirm-0"], "isController": false}, {"data": [0.9982078853046595, 500, 1500, "S01_IFEC_AccountActivity_TC01_Click_Account_Activity"], "isController": true}, {"data": [0.4815303430079156, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft"], "isController": true}, {"data": [0.9375, 500, 1500, "Login-0"], "isController": false}, {"data": [0.984375, 500, 1500, "Login-1"], "isController": false}, {"data": [0.9478041756659468, 500, 1500, "S01_IFEC_AccountActivity_TC03_Click_Back"], "isController": true}, {"data": [0.828125, 500, 1500, "Login-2"], "isController": false}, {"data": [0.796875, 500, 1500, "Logout-0"], "isController": false}, {"data": [0.6875, 500, 1500, "Launch_Application-0"], "isController": false}, {"data": [0.9982078853046595, 500, 1500, "S01_IFEC_AccountActivity_TC01_Click_Account_Activity-0"], "isController": false}, {"data": [0.9953519256308101, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC06_Click_Back-0"], "isController": false}, {"data": [0.9906609195402298, 500, 1500, "S01_IFEC_AccountActivity_TC02_Select_Account_Click_Search"], "isController": true}, {"data": [0.9641649763353617, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC03_Click_Back-0"], "isController": false}, {"data": [0.953042328042328, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC04_Click_Initiate-0"], "isController": false}, {"data": [1.0, 500, 1500, "Launch_Application-2"], "isController": false}, {"data": [0.9166666666666666, 500, 1500, "Launch_Application-1"], "isController": false}, {"data": [0.9927152317880795, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC05_Click_Confirm"], "isController": true}, {"data": [0.9625506072874493, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC02_Select_Account_Click_Search"], "isController": true}, {"data": [0.953042328042328, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC04_Click_Initiate"], "isController": true}, {"data": [0.9953519256308101, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC06_Click_Back"], "isController": true}, {"data": [0.9919441460794844, 500, 1500, "S04_IFEC_TermDeposit_TC03_Click_Initiate"], "isController": true}, {"data": [0.484375, 500, 1500, "Login"], "isController": true}, {"data": [0.9478041756659468, 500, 1500, "S01_IFEC_AccountActivity_TC03_Click_Back-0"], "isController": false}, {"data": [0.9492084432717678, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-1"], "isController": false}, {"data": [0.9839743589743589, 500, 1500, "S04_IFEC_TermDeposit_TC01_Click_Term_Deposit_Placement-0"], "isController": false}, {"data": [0.9366754617414248, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-2"], "isController": false}, {"data": [0.9811827956989247, 500, 1500, "S04_IFEC_TermDeposit_TC04_Click_Confirm-0"], "isController": false}, {"data": [0.993421052631579, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC01_Initiate_Payment"], "isController": true}, {"data": [0.9641649763353617, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC03_Click_Back"], "isController": true}, {"data": [0.9967018469656992, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-0"], "isController": false}, {"data": [0.9870967741935484, 500, 1500, "S04_IFEC_TermDeposit_TC05_Click_Back"], "isController": true}, {"data": [0.9633243606998654, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC01_Click_End_Of_Day_Balance-0"], "isController": false}, {"data": [0.9796573875802997, 500, 1500, "S04_IFEC_TermDeposit_TC02_Click_Draft-0"], "isController": false}, {"data": [0.9625506072874493, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC02_Select_Account_Click_Search-0"], "isController": false}, {"data": [0.9887580299785867, 500, 1500, "S04_IFEC_TermDeposit_TC02_Click_Draft-1"], "isController": false}, {"data": [0.994729907773386, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC02_Select_Payment_Mode"], "isController": true}, {"data": [0.453125, 500, 1500, "Launch_Application"], "isController": true}, {"data": [0.796875, 500, 1500, "Logout"], "isController": true}, {"data": [0.9400428265524625, 500, 1500, "S04_IFEC_TermDeposit_TC02_Click_Draft"], "isController": true}, {"data": [0.9633243606998654, 500, 1500, "S02_IFEC_End_OfDay_Balance_TC01_Click_End_Of_Day_Balance"], "isController": true}, {"data": [0.9839743589743589, 500, 1500, "S04_IFEC_TermDeposit_TC01_Click_Term_Deposit_Placement"], "isController": true}, {"data": [0.9919441460794844, 500, 1500, "S04_IFEC_TermDeposit_TC03_Click_Initiate-0"], "isController": false}, {"data": [0.9870967741935484, 500, 1500, "S04_IFEC_TermDeposit_TC05_Click_Back-0"], "isController": false}, {"data": [0.993421052631579, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC01_Initiate_Payment-0"], "isController": false}, {"data": [0.9906609195402298, 500, 1500, "S01_IFEC_AccountActivity_TC02_Select_Account_Click_Search-0"], "isController": false}, {"data": [0.875, 500, 1500, "Enter_Username"], "isController": true}, {"data": [0.994729907773386, 500, 1500, "S03_IFEC_Initiate_Payment_Click_TC02_Select_Payment_Mode-0"], "isController": false}, {"data": [0.9811827956989247, 500, 1500, "S04_IFEC_TermDeposit_TC04_Click_Confirm"], "isController": true}, {"data": [0.515625, 500, 1500, "Enter_Response_Code"], "isController": true}, {"data": [0.875, 500, 1500, "Enter_Username-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 20523, 5, 0.024362909905959167, 274.3306046874253, 20, 74946, 129.0, 418.0, 479.0, 828.0, 5.475678016365402, 6.353290331064675, 5.521176409487493], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Enter_Response_Code-0", 32, 0, 0.0, 893.6875, 178, 2178, 822.5, 1502.1999999999998, 1767.8499999999985, 2178.0, 0.2981486830213642, 0.5336977890411725, 0.25721329102572466], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC05_Click_Confirm-0", 755, 0, 0.0, 127.41589403973511, 95, 1741, 108.0, 133.0, 183.39999999999986, 450.8799999999999, 0.20559456859996364, 0.2234577773600078, 0.25618478839825765], "isController": false}, {"data": ["S01_IFEC_AccountActivity_TC01_Click_Account_Activity", 1395, 0, 0.0, 132.78279569892456, 104, 550, 117.0, 188.4000000000001, 200.0, 452.15999999999985, 0.37828087476977745, 0.42763735578550094, 0.41864084469780377], "isController": true}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft", 758, 2, 0.2638522427440633, 1070.9366754617424, 526, 30767, 905.5, 1315.0, 1386.1, 2825.369999999998, 0.20632076455180623, 0.6911450030090713, 0.8211177919064556], "isController": true}, {"data": ["Login-0", 32, 0, 0.0, 321.8125, 102, 1845, 216.0, 485.4, 1117.6499999999976, 1845.0, 0.30075470634122503, 1.5537126905563021, 0.2424173981898326], "isController": false}, {"data": ["Login-1", 32, 0, 0.0, 225.71874999999997, 103, 810, 136.5, 438.6, 573.3999999999992, 810.0, 0.3010716268217185, 0.8102693062180699, 0.24002670834627], "isController": false}, {"data": ["S01_IFEC_AccountActivity_TC03_Click_Back", 1389, 0, 0.0, 459.80201583873276, 388, 4197, 407.0, 501.0, 814.0, 927.0999999999863, 0.3787510051626298, 0.419579612373978, 0.4191599424899729], "isController": true}, {"data": ["Login-2", 32, 0, 0.0, 502.03125000000006, 103, 1849, 434.5, 772.1999999999999, 1375.1499999999985, 1849.0, 0.30029748219329777, 0.8693304187273017, 0.2285589357269545], "isController": false}, {"data": ["Logout-0", 32, 0, 0.0, 509.3437500000001, 100, 2037, 395.0, 715.7, 1347.9999999999977, 2037.0, 0.2851312940505573, 0.3894363728403532, 0.2402227671769329], "isController": false}, {"data": ["Launch_Application-0", 24, 0, 0.0, 858.1666666666665, 442, 4289, 544.5, 2358.0, 4105.0, 4289.0, 0.22699972570866475, 0.7536915534820812, 0.11763787868756324], "isController": false}, {"data": ["S01_IFEC_AccountActivity_TC01_Click_Account_Activity-0", 1395, 0, 0.0, 132.78279569892456, 104, 550, 117.0, 188.4000000000001, 200.0, 452.15999999999985, 0.37828087476977745, 0.42763735578550094, 0.41864084469780377], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC06_Click_Back-0", 753, 0, 0.0, 121.64409030544493, 91, 972, 107.0, 146.80000000000007, 185.19999999999982, 477.0400000000027, 0.2071361569503396, 0.22471046197483557, 0.22659627266669236], "isController": false}, {"data": ["S01_IFEC_AccountActivity_TC02_Select_Account_Click_Search", 1392, 0, 0.0, 135.94827586206893, 105, 956, 119.0, 167.0, 196.0, 601.1399999999999, 0.3774263266250685, 0.4125828594152007, 0.5588518187671716], "isController": true}, {"data": ["S02_IFEC_End_OfDay_Balance_TC03_Click_Back-0", 1479, 0, 0.0, 442.6342123056117, 377, 4187, 404.0, 478.0, 757.0, 838.2, 0.40275902184293705, 0.43505349296437995, 0.0], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC04_Click_Initiate-0", 756, 1, 0.13227513227513227, 454.7486772486768, 51, 3411, 392.0, 469.30000000000007, 801.15, 1810.4399999999996, 0.20582601983934137, 0.2251549119011545, 0.24761688232795762], "isController": false}, {"data": ["Launch_Application-2", 8, 0, 0.0, 221.0, 190, 352, 203.5, 352.0, 352.0, 352.0, 0.07641754546843955, 0.37530604331441997, 0.07522352132049519], "isController": false}, {"data": ["Launch_Application-1", 24, 0, 0.0, 406.8333333333333, 186, 1887, 254.0, 874.0, 1699.75, 1887.0, 0.22635957218040859, 0.9258029133184313, 0.12496934714126724], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC05_Click_Confirm", 755, 0, 0.0, 127.41589403973511, 95, 1741, 108.0, 133.0, 183.39999999999986, 450.8799999999999, 0.2055945126143807, 0.22345771651008353, 0.25618471863642095], "isController": true}, {"data": ["S02_IFEC_End_OfDay_Balance_TC02_Select_Account_Click_Search", 1482, 2, 0.1349527665317139, 523.1497975708501, 385, 74946, 407.0, 481.0, 801.8499999999999, 1224.3600000000006, 0.4034344741563741, 0.4350224432544368, 0.0], "isController": true}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC04_Click_Initiate", 756, 1, 0.13227513227513227, 454.7486772486768, 51, 3411, 392.0, 469.30000000000007, 801.15, 1810.4399999999996, 0.20582596380185603, 0.2251548506012514, 0.2476168149126356], "isController": true}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC06_Click_Back", 753, 0, 0.0, 121.64409030544493, 91, 972, 107.0, 146.80000000000007, 185.19999999999982, 477.0400000000027, 0.20713609997108895, 0.22471040016122504, 0.22659621033433086], "isController": true}, {"data": ["S04_IFEC_TermDeposit_TC03_Click_Initiate", 931, 0, 0.0, 146.96025778732562, 90, 3409, 102.0, 382.0, 396.0, 517.0, 0.2541948984094116, 0.2834476933075753, 0.35624838653815494], "isController": true}, {"data": ["Login", 32, 0, 0.0, 1049.5625000000002, 314, 4135, 850.0, 1639.6, 2522.349999999995, 4135.0, 0.2991940460384838, 3.217002534383941, 0.7074083835106681], "isController": true}, {"data": ["S01_IFEC_AccountActivity_TC03_Click_Back-0", 1389, 0, 0.0, 459.80201583873276, 388, 4197, 407.0, 501.0, 814.0, 927.0999999999863, 0.378751108440069, 0.4195797267845204, 0.4191600567860801], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-1", 758, 2, 0.2638522427440633, 482.1213720316624, 20, 30178, 392.0, 485.30000000000007, 797.0, 1293.7699999999936, 0.20634896004752015, 0.22468554837916702, 0.2324669144079214], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC01_Click_Term_Deposit_Placement-0", 936, 0, 0.0, 165.6570512820513, 98, 3764, 111.0, 396.0, 419.44999999999993, 802.0099999999999, 0.2531273122206405, 0.34067726286284283, 0.28056591735393255], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-2", 758, 0, 0.0, 473.02110817941957, 389, 4608, 404.0, 740.3000000000014, 824.0, 1560.0699999999993, 0.20634873535175788, 0.23931967921074604, 0.34287261378649114], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC04_Click_Confirm-0", 930, 0, 0.0, 172.61612903225839, 96, 3855, 109.0, 396.0, 457.7999999999997, 809.0699999999998, 0.2539170805105535, 0.2824222270582505, 0.39601780503086187], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC01_Initiate_Payment", 760, 0, 0.0, 126.65921052631576, 90, 1093, 105.0, 175.0, 190.94999999999993, 643.0, 0.20680879873476554, 0.2249927940059191, 0.22623379561222481], "isController": true}, {"data": ["S02_IFEC_End_OfDay_Balance_TC03_Click_Back", 1479, 0, 0.0, 442.6342123056117, 377, 4187, 404.0, 478.0, 757.0, 838.2, 0.40275902184293705, 0.43505349296437995, 0.0], "isController": true}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-0", 758, 0, 0.0, 115.79419525065963, 91, 913, 102.0, 137.0, 180.0, 443.81999999999994, 0.20636513942851012, 0.2272517826218228, 0.24590938283483083], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC05_Click_Back", 930, 0, 0.0, 147.69462365591417, 101, 1234, 111.0, 190.0, 399.44999999999993, 797.0699999999998, 0.2539370481866028, 0.3138148559146171, 0.2814628941314602], "isController": true}, {"data": ["S02_IFEC_End_OfDay_Balance_TC01_Click_End_Of_Day_Balance-0", 1486, 0, 0.0, 447.0800807537009, 376, 3774, 403.0, 475.0, 720.9499999999996, 944.9199999999782, 0.40234802291705024, 0.43648905320957837, 0.0], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC02_Click_Draft-0", 934, 0, 0.0, 173.16488222698092, 89, 1050, 103.0, 393.5, 461.0, 807.5999999999999, 0.2526296884242859, 0.3413880227189554, 0.4159061946442777], "isController": false}, {"data": ["S02_IFEC_End_OfDay_Balance_TC02_Select_Account_Click_Search-0", 1482, 2, 0.1349527665317139, 523.1497975708501, 385, 74946, 407.0, 481.0, 801.8499999999999, 1224.3600000000006, 0.4034344741563741, 0.4350224432544368, 0.0], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC02_Click_Draft-1", 934, 0, 0.0, 128.54710920770884, 94, 1621, 105.0, 172.0, 185.5, 759.3499999999996, 0.2526881938610837, 0.3126636474790024, 0.44642445740688885], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC02_Select_Payment_Mode", 759, 0, 0.0, 118.65480895915684, 90, 1167, 101.0, 123.0, 179.0, 823.5999999999999, 0.2065957109750501, 0.2494860327757699, 0.2243954842607548], "isController": true}, {"data": ["Launch_Application", 32, 0, 0.0, 1003.9999999999995, 573, 4527, 669.0, 1881.0999999999995, 4026.499999999998, 4527.0, 0.30161931871736386, 2.0466262524270933, 0.31634682451411017], "isController": true}, {"data": ["Logout", 32, 0, 0.0, 509.3437500000001, 100, 2037, 395.0, 715.7, 1347.9999999999977, 2037.0, 0.2851312940505573, 0.3894363728403532, 0.2402227671769329], "isController": true}, {"data": ["S04_IFEC_TermDeposit_TC02_Click_Draft", 934, 0, 0.0, 301.7119914346895, 192, 2654, 210.5, 505.0, 609.5, 1451.7499999999995, 0.25261738932640143, 0.6539474399972844, 0.8621853135173834], "isController": true}, {"data": ["S02_IFEC_End_OfDay_Balance_TC01_Click_End_Of_Day_Balance", 1486, 0, 0.0, 447.0800807537009, 376, 3774, 403.0, 475.0, 720.9499999999996, 944.9199999999782, 0.40234791397769104, 0.4364889350262271, 0.0], "isController": true}, {"data": ["S04_IFEC_TermDeposit_TC01_Click_Term_Deposit_Placement", 936, 0, 0.0, 165.6570512820513, 98, 3764, 111.0, 396.0, 419.44999999999993, 802.0099999999999, 0.25312738067518487, 0.3406773549939788, 0.28056599322884257], "isController": true}, {"data": ["S04_IFEC_TermDeposit_TC03_Click_Initiate-0", 931, 0, 0.0, 146.96025778732562, 90, 3409, 102.0, 382.0, 396.0, 517.0, 0.25419496781334716, 0.28344777069852833, 0.35624848380619695], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC05_Click_Back-0", 930, 0, 0.0, 147.69462365591417, 101, 1234, 111.0, 190.0, 399.44999999999993, 797.0699999999998, 0.2539371175242824, 0.3138149416019719, 0.2814629709850903], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC01_Initiate_Payment-0", 760, 0, 0.0, 126.65921052631576, 90, 1093, 105.0, 175.0, 190.94999999999993, 643.0, 0.20680885501093774, 0.22499285523026397, 0.2262338571742672], "isController": false}, {"data": ["S01_IFEC_AccountActivity_TC02_Select_Account_Click_Search-0", 1392, 0, 0.0, 135.94827586206893, 105, 956, 119.0, 167.0, 196.0, 601.1399999999999, 0.3774264289603203, 0.4125829712827835, 0.5588519702940726], "isController": false}, {"data": ["Enter_Username", 32, 0, 0.0, 336.6875, 200, 1348, 234.0, 534.8, 862.4499999999985, 1348.0, 0.3014999623125047, 0.5513544385269843, 0.2811104384940077], "isController": true}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC02_Select_Payment_Mode-0", 759, 0, 0.0, 118.65480895915684, 90, 1167, 101.0, 123.0, 179.0, 823.5999999999999, 0.20659576720930492, 0.2494861006845424, 0.22439554534001335], "isController": false}, {"data": ["S04_IFEC_TermDeposit_TC04_Click_Confirm", 930, 0, 0.0, 172.61612903225839, 96, 3855, 109.0, 396.0, 457.7999999999997, 809.0699999999998, 0.2539170111838157, 0.28242214994877973, 0.396017696906499], "isController": true}, {"data": ["Enter_Response_Code", 32, 0, 0.0, 893.6875, 178, 2178, 822.5, 1502.1999999999998, 1767.8499999999985, 2178.0, 0.2981486830213642, 0.5336977890411725, 0.25721329102572466], "isController": true}, {"data": ["Enter_Username-0", 32, 0, 0.0, 336.6875, 200, 1348, 234.0, 534.8, 862.4499999999985, 1348.0, 0.3014999623125047, 0.5513544385269843, 0.2811104384940077], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: javax.net.ssl.SSLException\/Non HTTP response message: Unrecognized SSL message, plaintext connection?", 3, 60.0, 0.0146177459435755], "isController": false}, {"data": ["407\/Proxy Authentication Required", 2, 40.0, 0.009745163962383667], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 20523, 5, "Non HTTP response code: javax.net.ssl.SSLException\/Non HTTP response message: Unrecognized SSL message, plaintext connection?", 3, "407\/Proxy Authentication Required", 2, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC04_Click_Initiate-0", 756, 1, "407\/Proxy Authentication Required", 1, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S03_IFEC_Initiate_Payment_Click_TC03_Select_Account_Details_Click_Save_Draft-1", 758, 2, "Non HTTP response code: javax.net.ssl.SSLException\/Non HTTP response message: Unrecognized SSL message, plaintext connection?", 1, "407\/Proxy Authentication Required", 1, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["S02_IFEC_End_OfDay_Balance_TC02_Select_Account_Click_Search-0", 1482, 2, "Non HTTP response code: javax.net.ssl.SSLException\/Non HTTP response message: Unrecognized SSL message, plaintext connection?", 2, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
